document.addEventListener('DOMContentLoaded', () => {
  console.log('Popup script loaded'); // 调试日志

  const urlInput = document.getElementById('urlInput');
  const previewButton = document.getElementById('previewButton');
  const historyButton = document.getElementById('historyButton');
  const historyPanel = document.getElementById('historyPanel');
  const error = document.getElementById('error');

  if (!urlInput || !previewButton || !historyButton || !historyPanel || !error) {
    console.error('Some elements were not found:', {
      urlInput: !!urlInput,
      previewButton: !!previewButton,
      historyButton: !!historyButton,
      historyPanel: !!historyPanel,
      error: !!error
    });
    return;
  }

  console.log('All elements found successfully'); // 调试日志

  // 历史记录状态
  let isHistoryVisible = false;

  // 显示错误信息
  function showError(message, duration = 3000) {
    console.log('Showing error:', message); // 调试日志
    error.textContent = message;
    error.style.display = 'block';
    setTimeout(() => {
      error.style.display = 'none';
    }, duration);
  }

  // 保存URL到历史记录
  async function saveToHistory(url) {
    console.log('Saving URL to history:', url); // 调试日志
    try {
      const { history = [] } = await chrome.storage.local.get('history');
      console.log('Current history:', history); // 调试日志
      
      const newHistory = [
        { url, timestamp: Date.now() },
        ...history.filter(item => item.url !== url)
      ].slice(0, 20);
      
      await chrome.storage.local.set({ history: newHistory });
      console.log('History saved successfully'); // 调试日志
      
      if (isHistoryVisible) {
        await loadHistory();
      }
    } catch (e) {
      console.error('Error saving to history:', e); // 调试日志
      showError('保存历史记录失败: ' + e.message);
    }
  }

  // 加载历史记录
  async function loadHistory() {
    console.log('Loading history'); // 调试日志
    try {
      const { history = [] } = await chrome.storage.local.get('history');
      console.log('Retrieved history:', history); // 调试日志
      
      historyPanel.innerHTML = '';
      
      if (history.length === 0) {
        historyPanel.innerHTML = '<div class="history-item"><div class="history-url">暂无历史记录</div></div>';
        return;
      }

      history.forEach(({ url, timestamp }) => {
        const item = document.createElement('div');
        item.className = 'history-item';
        
        const urlSpan = document.createElement('div');
        urlSpan.className = 'history-url';
        urlSpan.title = url;
        urlSpan.textContent = url;
        
        const importButton = document.createElement('button');
        importButton.className = 'import-button';
        importButton.textContent = '导入';
        importButton.onclick = () => {
          urlInput.value = url;
          urlInput.focus();
        };

        const date = new Date(timestamp);
        const timeSpan = document.createElement('div');
        timeSpan.className = 'history-time';
        timeSpan.textContent = date.toLocaleString();
        timeSpan.style.fontSize = '12px';
        timeSpan.style.color = '#666';
        timeSpan.style.marginTop = '4px';
        
        const leftContainer = document.createElement('div');
        leftContainer.style.flex = '1';
        leftContainer.appendChild(urlSpan);
        leftContainer.appendChild(timeSpan);
        
        item.appendChild(leftContainer);
        item.appendChild(importButton);
        historyPanel.appendChild(item);
      });
      console.log('History loaded successfully'); // 调试日志
    } catch (e) {
      console.error('Error loading history:', e); // 调试日志
      showError('加载历史记录失败: ' + e.message);
    }
  }

  // 新增：统一处理URL预览和窗口创建的函数
  async function openUrlInPreviewWindow(url) {
    console.log('Attempting to open URL:', url);
    if (!url) {
      showError('URL 不能为空');
      return;
    }

    let processedUrl = url.trim();
    // 自动添加协议头
    if (!processedUrl.match(/^https?:\/\//)) {
      processedUrl = 'https://' + processedUrl;
    }

    try {
      // 验证URL是否有效
      new URL(processedUrl);

      // 核心改动：立即创建窗口，以保留用户操作的上下文
      chrome.windows.create({
        url: processedUrl,
        type: 'popup',
        width: 800,
        height: 600,
        left: Math.max(screen.width - 850, 0),
        top: 30
      }, (window) => {
        if (chrome.runtime.lastError) {
          showError('无法打开预览窗口: ' + chrome.runtime.lastError.message);
          console.error('Window creation error:', chrome.runtime.lastError);
        } else {
          console.log('Preview window created successfully for URL:', processedUrl);
        }
      });
      
      // 然后再异步保存到历史记录，这不再阻塞窗口创建
      await saveToHistory(processedUrl);

    } catch (e) {
      console.error('URL processing error:', e, 'Original URL was:', url);
      showError('请输入一个有效的网址');
    }
  }

  // 处理URL预览
  function handlePreview() {
    console.log('Handle preview clicked'); // 调试日志
    openUrlInPreviewWindow(urlInput.value);
  }

  // 事件监听器
  console.log('Adding event listeners'); // 调试日志
  
  previewButton.addEventListener('click', () => {
    console.log('Preview button clicked'); // 调试日志
    handlePreview();
  });
  
  urlInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      console.log('Enter key pressed'); // 调试日志
      handlePreview();
    }
  });

  historyButton.addEventListener('click', () => {
    console.log('History button clicked'); // 调试日志
    isHistoryVisible = !isHistoryVisible;
    historyPanel.style.display = isHistoryVisible ? 'block' : 'none';
    if (isHistoryVisible) {
      loadHistory();
    }
  });

  // 初始化
  console.log('Initialization complete'); // 调试日志
  urlInput.focus();
  populateHotModels();
  populateAgentLists(); // 新增：填充ZZAgent列表

  // 新增配置面板的元素获取
  const addConfigPanel = document.getElementById('addConfigPanel');
  const addConfigButton = document.getElementById('addConfigButton');
  const saveConfigButton = document.getElementById('saveConfigButton');
  const cancelConfigButton = document.getElementById('cancelConfigButton');
  const agentNameInput = document.getElementById('agentNameInput');
  const agentUrlInput = document.getElementById('agentUrlInput');

  // "新增配置"按钮点击事件
  addConfigButton.addEventListener('click', () => {
    addConfigPanel.style.display = 'flex';
    agentNameInput.focus();
  });

  // "取消"按钮点击事件
  cancelConfigButton.addEventListener('click', () => {
    addConfigPanel.style.display = 'none';
    agentNameInput.value = '';
    agentUrlInput.value = '';
  });

  // "保存"按钮点击事件
  saveConfigButton.addEventListener('click', async () => {
    const name = agentNameInput.value.trim();
    const url = agentUrlInput.value.trim();

    if (!name || !url) {
      showError('名称和URL地址不能为空');
      return;
    }

    try {
      // 验证URL格式
      new URL(url);

      const { localAgents = [] } = await chrome.storage.local.get('localAgents');
      
      // 检查名称是否重复
      if (localAgents.some(agent => agent.name === name)) {
        showError('该名称已存在，请使用其他名称');
        return;
      }

      const newAgent = { name, url };
      const newLocalAgents = [newAgent, ...localAgents];

      await chrome.storage.local.set({ localAgents: newLocalAgents });

      // 清空输入框并隐藏面板
      agentNameInput.value = '';
      agentUrlInput.value = '';
      addConfigPanel.style.display = 'none';

      // 重新加载列表
      await populateAgentLists();

    } catch (e) {
      showError('请输入有效的URL地址');
    }
  });

  // ===================================================================
  //                      动态内容填充函数
  // ===================================================================

  // 填充热门模型列表
  function populateHotModels() {
    const models = [
      { name: '文心一言', url: 'https://yiyan.baidu.com' },
      { name: '腾讯混元', url: 'https://yuanbao.tencent.com/chat/naQivTmsDa' },
      { name: '通义千问', url: 'https://www.tongyi.com/' },
      { name: '豆包', url: 'https://www.doubao.com/chat/?from_logout=1' },
      { name: 'DeepSeek', url: 'https://chat.deepseek.com/' },
      { name: 'Kimi', url: 'https://www.kimi.com/' },
      { name: '科大讯飞', url: 'https://console.xfyun.cn/services/sparkapiCenter' },
      { name: 'Claude (亚)', url: 'https://jp.claude.global/zh-cn/' },
      { name: 'Claude (全球)', url: 'https://claude.ai' },
      { name: 'ChatGPT (OpenAI)', url: 'https://chat.openai.com/' },
      { name: '整合模型 (路线1)', url: 'https://droidx.me/chat/newChat' },
      { name: '整合模型 (路线2)', url: 'https://xsimplechat.com/chat' },
      { name: '扣子 Coze', url: 'https://www.coze.cn/studio' },
    ];

    const listContainer = document.getElementById('hot-models-list');
    if (!listContainer) {
      console.error('Hot models container not found');
      return;
    }

    listContainer.innerHTML = ''; // 清空容器

    models.forEach(model => {
      const link = document.createElement('a');
      link.href = model.url;
      link.textContent = model.name;
      link.className = 'model-link';
      link.title = `打开 ${model.name}`;

      link.addEventListener('click', (e) => {
        e.preventDefault(); // 阻止默认跳转
        openUrlInPreviewWindow(model.url);
      });

      listContainer.appendChild(link);
    });
  }

  // 创建一个可复用的函数来添加链接 (从 populateAgentLists 中提出)
  const addAgentLink = (container, model) => {
    const link = document.createElement('a');
    link.href = model.url;
    link.textContent = model.name;
    link.className = 'zzagent-link';
    link.title = `打开 ${model.name}`;

    link.addEventListener('click', (e) => {
      e.preventDefault();
      openUrlInPreviewWindow(model.url);
    });

    container.appendChild(link);
  };

  // 填充ZZAgent列表
  async function populateAgentLists() {
    const onlineListContainer = document.querySelector('#online-list-content');
    const localListContainer = document.querySelector('#local-list-content');
    const successToast = document.getElementById('online-list-success-toast');

    // 1. 线上列表：显示加载动画
    onlineListContainer.innerHTML = `
      <div class="loader-container">
        <div class="loader"></div>
        <div>ZZAgent数据加载中...</div>
      </div>
    `;

    // 2. 线上列表：异步加载数据
    setTimeout(() => {
      const agentModels = [
        { name: '聚合查询-qc', url: 'https://zzdify.zhuanspirit.com/chat/UolxvvkNaemD31DV' },
        { name: '数据构造专家', url: 'https://www.baidu.com/' },
      ];
      
      onlineListContainer.innerHTML = ''; // 清空加载动画
      agentModels.forEach(model => {
        addAgentLink(onlineListContainer, model);
      });

      // 显示成功提示，并在2.5秒后自动隐藏
      successToast.classList.add('show');
      setTimeout(() => {
        successToast.classList.remove('show');
      }, 2500);

    }, 2000); // 模拟2秒加载时间

    // 3. 本地列表：立即加载
    localListContainer.innerHTML = ''; // 清空现有内容
    const { localAgents = [] } = await chrome.storage.local.get('localAgents');
    
    // 保持原有逻辑：本地列表也包含线上模型
    const agentModelsForLocal = [
        { name: '聚合查询-qc', url: 'https://zzdify.zhuanspirit.com/chat/UolxvvkNaemD31DV' },
        { name: '数据构造专家', url: 'https://www.baidu.com/' },
    ];
    const allLocalModels = [...agentModelsForLocal, ...localAgents];

    allLocalModels.forEach(model => {
      addAgentLink(localListContainer, model);
    });
  }
}); 